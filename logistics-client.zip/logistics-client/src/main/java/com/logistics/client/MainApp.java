package com.logistics.client;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import com.logistics.client.view.*;
import com.logistics.client.util.PreferencesUtil;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.UserView;

/**
 * Главный класс клиентского приложения.
 * Запускает окно входа, а после успешной аутентификации — главное окно с вкладками.
 * Управляет настройками окна (сохранение/загрузка размеров и позиции) и пунктами меню.
 */
public class MainApp extends Application {

    /**
     * Точка входа в JavaFX-приложение.
     * Сначала показывает окно логина, а после успешного входа вызывает {@link #showMainWindow(Stage)}.
     *
     * @param primaryStage основная сцена (не используется напрямую, так как сначала показывается логин)
     */
    @Override
    public void start(Stage primaryStage) {
        LoginWindow loginWindow = new LoginWindow(() -> {
            // после успешного логина открываем главное окно
            showMainWindow(primaryStage);
        });
        loginWindow.show();
    }

    /**
     * Создаёт и отображает главное окно приложения с вкладками и меню.
     * Вкладки: Клиенты, Грузы, Транспорт, Водители, Маршруты, Заказы.
     * Если текущий пользователь — администратор, добавляется вкладка "Пользователи".
     *
     * @param primaryStage основная сцена, на которой будет размещено главное окно
     */
    private void showMainWindow(Stage primaryStage) {
        TabPane tabPane = new TabPane();

        // Основные вкладки
        Tab clientTab = new Tab("Клиенты", new ClientView());
        Tab cargoTab = new Tab("Грузы", new CargoView());
        Tab vehicleTab = new Tab("Транспорт", new VehicleView());
        Tab driverTab = new Tab("Водители", new DriverView());
        Tab routeTab = new Tab("Маршруты", new RouteView());
        Tab orderTab = new Tab("Заказы", new OrderView());

        tabPane.getTabs().addAll(clientTab, cargoTab, vehicleTab, driverTab, routeTab, orderTab);

        // Вкладка "Пользователи" только для администратора
        if (AuthManager.getInstance().isAdmin()) {
            Tab userTab = new Tab("Пользователи", new UserView());
            tabPane.getTabs().add(userTab);
        }

        // Создание меню
        MenuBar menuBar = new MenuBar();
        Menu fileMenu = new Menu("Файл");

        MenuItem logoutItem = new MenuItem("Сменить пользователя");
        logoutItem.setOnAction(e -> {
            AuthManager.getInstance().logout();
            primaryStage.close();
            LoginWindow loginWindow = new LoginWindow(() -> {
                showMainWindow(new Stage());
            });
            loginWindow.show();
        });

        MenuItem exitItem = new MenuItem("Выход");
        exitItem.setOnAction(e -> {
            PreferencesUtil.saveWindowPosition(primaryStage);
            Platform.exit();
        });

        fileMenu.getItems().addAll(logoutItem, exitItem);

        Menu reportMenu = new Menu("Отчеты");
        MenuItem statsItem = new MenuItem("Статистика");
        statsItem.setOnAction(e -> new StatisticsWindow().show());
        reportMenu.getItems().add(statsItem);

        Menu helpMenu = new Menu("Справка");
        MenuItem aboutItem = new MenuItem("Об авторе");
        aboutItem.setOnAction(e -> showAboutDialog());
        helpMenu.getItems().add(aboutItem);

        menuBar.getMenus().addAll(fileMenu, reportMenu, helpMenu);

        VBox root = new VBox(menuBar, tabPane);
        Scene scene = new Scene(root, 1200, 600);

        PreferencesUtil.loadWindowPosition(primaryStage);
        primaryStage.setTitle("Логистическая компания");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Отображает диалог с информацией об авторе.
     */
    private void showAboutDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Об авторе");
        alert.setHeaderText("Логистическая компания");
        alert.setContentText("Курсовой проект\nНовиков Максим\nГруппа ДПИ23-1\n2026");
        alert.showAndWait();
    }

    /**
     * Точка входа в приложение.
     *
     * @param args аргументы командной строки (не используются)
     */
    public static void main(String[] args) {
        launch(args);
    }
}