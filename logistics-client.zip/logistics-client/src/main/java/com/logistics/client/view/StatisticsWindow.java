package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.OrderStatus;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;
import java.util.Map;

/**
 * Окно отображения статистических данных.
 * Содержит текстовые показатели (количество заказов, средний вес и т.д.),
 * круговую диаграмму распределения заказов по статусам,
 * гистограммы по дням недели и топ-5 грузов,
 * а также линейный график динамики заказов по месяцам.
 * Все данные загружаются с сервера через {@link ApiClient}.
 */
public class StatisticsWindow extends Stage {
    private final ApiClient apiClient = new ApiClient();

    public StatisticsWindow() {
        setTitle("Статистика");
        VBox root = new VBox(10);
        root.setStyle("-fx-padding: 10;");

        try {
            // 1. Текстовые показатели
            long totalOrders = apiClient.getTotalOrders();
            root.getChildren().add(new Label("Общее количество заказов: " + totalOrders));

            Double avgWeight = apiClient.getAverageWeight();
            root.getChildren().add(new Label("Средний вес груза: " + String.format("%.2f", avgWeight) + " кг"));

            double avgDistance = apiClient.getAverageRouteDistance();
            root.getChildren().add(new Label("Средняя дистанция маршрутов: " + String.format("%.1f", avgDistance) + " км"));

            double totalWeight = apiClient.getTotalCargoWeight();
            root.getChildren().add(new Label("Общий вес всех грузов: " + String.format("%.2f", totalWeight) + " кг"));

            Map<String, Object> popularCargo = apiClient.getMostPopularCargo();
            String cargoName = (String) popularCargo.get("name");
            Long cargoCount = ((Number) popularCargo.get("count")).longValue();
            root.getChildren().add(new Label("Самый популярный груз: " + cargoName + " (" + cargoCount + " заказов)"));

            Map<String, Object> busyDriver = apiClient.getMostBusyDriver();
            String driverName = (String) busyDriver.get("name");
            Long driverCount = ((Number) busyDriver.get("count")).longValue();
            root.getChildren().add(new Label("Самый занятой водитель: " + driverName + " (" + driverCount + " доставок)"));

            // 2. Круговая диаграмма по статусам
            Map<OrderStatus, Long> statusCounts = apiClient.getOrdersByStatus();
            PieChart pieChart = new PieChart();
            pieChart.setTitle("Распределение заказов по статусам");
            pieChart.setLabelsVisible(true);
            pieChart.setLegendVisible(false);
            for (Map.Entry<OrderStatus, Long> entry : statusCounts.entrySet()) {
                if (entry.getValue() > 0) {
                    pieChart.getData().add(new PieChart.Data(
                            entry.getKey().getDisplayName() + " (" + entry.getValue() + ")",
                            entry.getValue()
                    ));
                }
            }
            root.getChildren().add(pieChart);

            // 3. Гистограмма по дням недели
            Map<String, Long> weekdayData = apiClient.getOrdersByWeekday();
            CategoryAxis weekdayXAxis = new CategoryAxis();
            NumberAxis weekdayYAxis = new NumberAxis();
            BarChart<String, Number> weekdayChart = new BarChart<>(weekdayXAxis, weekdayYAxis);
            weekdayChart.setTitle("Заказы по дням недели");
            weekdayChart.setAnimated(false);
            XYChart.Series<String, Number> weekdaySeries = new XYChart.Series<>();
            for (Map.Entry<String, Long> entry : weekdayData.entrySet()) {
                weekdaySeries.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
            }
            weekdayChart.getData().add(weekdaySeries);
            root.getChildren().add(weekdayChart);

            // 4. Гистограмма топ-5 грузов
            List<Map<String, Object>> topCargos = apiClient.getTopCargos();
            CategoryAxis cargoXAxis = new CategoryAxis();
            NumberAxis cargoYAxis = new NumberAxis();
            BarChart<String, Number> cargoChart = new BarChart<>(cargoXAxis, cargoYAxis);
            cargoChart.setTitle("Топ-5 грузов по популярности");
            cargoChart.setAnimated(false);
            XYChart.Series<String, Number> cargoSeries = new XYChart.Series<>();
            for (Map<String, Object> cargo : topCargos) {
                String name = (String) cargo.get("name");
                Long count = ((Number) cargo.get("count")).longValue();
                cargoSeries.getData().add(new XYChart.Data<>(name, count));
            }
            cargoChart.getData().add(cargoSeries);
            root.getChildren().add(cargoChart);

            // 5. Линейный график по месяцам
            Map<String, Long> monthData = apiClient.getOrdersByMonth();
            CategoryAxis monthXAxis = new CategoryAxis();
            NumberAxis monthYAxis = new NumberAxis();
            LineChart<String, Number> monthChart = new LineChart<>(monthXAxis, monthYAxis);
            monthChart.setTitle("Динамика заказов по месяцам");
            monthChart.setAnimated(false);
            XYChart.Series<String, Number> monthSeries = new XYChart.Series<>();
            for (Map.Entry<String, Long> entry : monthData.entrySet()) {
                monthSeries.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
            }
            monthChart.getData().add(monthSeries);
            root.getChildren().add(monthChart);

        } catch (Exception e) {
            root.getChildren().add(new Label("Ошибка загрузки статистики: " + e.getMessage()));
        }

        // Оборачиваем в ScrollPane, чтобы всё помещалось
        ScrollPane scrollPane = new ScrollPane(root);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);
        Scene scene = new Scene(scrollPane, 900, 700);
        setScene(scene);
    }
}