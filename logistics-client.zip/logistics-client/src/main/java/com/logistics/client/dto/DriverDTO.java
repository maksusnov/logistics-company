package com.logistics.client.dto;

/**
 * DTO для передачи данных о водителе.
 * Содержит основную информацию: идентификатор, ФИО, телефон, категорию прав,
 * а также идентификатор и госномер закреплённого транспортного средства.
 */
public class DriverDTO {
    private Long id;
    private String name;
    private String phone;
    private String licenseCategory;
    private Long vehicleId;
    private String vehicleLicensePlate;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getLicenseCategory() { return licenseCategory; }
    public void setLicenseCategory(String licenseCategory) { this.licenseCategory = licenseCategory; }
    public Long getVehicleId() { return vehicleId; }
    public void setVehicleId(Long vehicleId) { this.vehicleId = vehicleId; }
    public String getVehicleLicensePlate() { return vehicleLicensePlate; }
    public void setVehicleLicensePlate(String vehicleLicensePlate) { this.vehicleLicensePlate = vehicleLicensePlate; }
}