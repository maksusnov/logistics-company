package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.OrderDTO;
import com.logistics.client.dto.OrderStatus;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.OrderEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

import java.time.LocalDate;

/**
 * Вкладка для отображения и управления заказами.
 * Содержит таблицу со списком заказов, панель фильтрации по статусу и датам,
 * а также панель инструментов для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class OrderView extends BorderPane {
    private final TableView<OrderDTO> table = new TableView<>();
    private final ObservableList<OrderDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    private final ComboBox<OrderStatus> statusFilter = new ComboBox<>();
    private final DatePicker startDateFilter = new DatePicker();
    private final DatePicker endDateFilter = new DatePicker();

    public OrderView() {
        createTable();
        createFilterBar();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Дата, Клиент, Груз, Статус, Водитель, ТС.
     */
    private void createTable() {
        TableColumn<OrderDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<OrderDTO, LocalDate> dateCol = new TableColumn<>("Дата");
        dateCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getOrderDate()));

        TableColumn<OrderDTO, String> clientCol = new TableColumn<>("Клиент");
        clientCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getClientName()));

        TableColumn<OrderDTO, String> cargoCol = new TableColumn<>("Груз");
        cargoCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getCargoDescription()));

        TableColumn<OrderDTO, String> statusCol = new TableColumn<>("Статус");
        statusCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(
                cellData.getValue().getStatus() != null ? cellData.getValue().getStatus().getDisplayName() : ""));

        TableColumn<OrderDTO, String> driverCol = new TableColumn<>("Водитель");
        driverCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getDriverName()));

        TableColumn<OrderDTO, String> vehicleCol = new TableColumn<>("ТС");
        vehicleCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getVehicleLicensePlate()));

        table.getColumns().addAll(idCol, dateCol, clientCol, cargoCol, statusCol, driverCol, vehicleCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель фильтрации с выпадающим списком статусов и полями для выбора дат.
     * Фильтрация применяется по кнопке "Применить", сброс – по кнопке "Сбросить".
     */
    private void createFilterBar() {
        HBox filterBox = new HBox(5);
        filterBox.setPadding(new Insets(5));
        filterBox.setAlignment(Pos.CENTER_LEFT);

        Label statusLabel = new Label("Статус:");
        statusFilter.getItems().add(null);
        statusFilter.getItems().addAll(OrderStatus.values());
        statusFilter.setPromptText("Все статусы");
        statusFilter.setPrefWidth(120);

        Label startLabel = new Label("Дата с:");
        startDateFilter.setPromptText("гггг-мм-дд");
        startDateFilter.setPrefWidth(100);

        Label endLabel = new Label("по:");
        endDateFilter.setPromptText("гггг-мм-дд");
        endDateFilter.setPrefWidth(100);

        Button applyFilter = new Button("Применить");
        applyFilter.setOnAction(e -> applyFilter());

        Button resetFilter = new Button("Сбросить");
        resetFilter.setOnAction(e -> {
            statusFilter.setValue(null);
            startDateFilter.setValue(null);
            endDateFilter.setValue(null);
            loadData();
        });

        filterBox.getChildren().addAll(
                statusLabel, statusFilter,
                startLabel, startDateFilter,
                endLabel, endDateFilter,
                applyFilter, resetFilter
        );

        setTop(filterBox);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            OrderDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите заказ для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            OrderDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteOrder(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить заказ: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите заказ для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setBottom(toolBar);
    }

    /**
     * Применяет фильтр по выбранным критериям и обновляет таблицу.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void applyFilter() {
        try {
            OrderStatus status = statusFilter.getValue();
            LocalDate start = startDateFilter.getValue();
            LocalDate end = endDateFilter.getValue();
            data.setAll(apiClient.filterOrders(status, start, end, null, null, null));
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось применить фильтр: " + e.getMessage());
        }
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getOrders());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить заказы: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования заказа.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param order объект заказа для редактирования (null для нового)
     */
    private void showEditDialog(OrderDTO order) {
        OrderEditDialog dialog = new OrderEditDialog(order, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}