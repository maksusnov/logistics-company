package com.logistics.client.dto;

/**
 * Перечисление возможных типов клиента.
 * Каждому значению соответствует русскоязычное отображаемое имя,
 * используемое в пользовательском интерфейсе.
 */
public enum ClientType {
    INDIVIDUAL("Физическое лицо"),
    LEGAL("Юридическое лицо");

    private final String displayName;

    ClientType(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Возвращает русскоязычное название типа клиента для отображения в интерфейсе.
     *
     * @return отображаемое имя
     */
    public String getDisplayName() {
        return displayName;
    }
}