package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.DriverDTO;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования водителя.
 * Позволяет ввести имя, телефон, категорию прав и госномер транспортного средства.
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class DriverEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final DriverDTO driver;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param driver         объект водителя для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public DriverEditDialog(DriverDTO driver, Runnable onSaveCallback) {
        this.driver = driver != null ? driver : new DriverDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(driver == null ? "Добавление водителя" : "Редактирование водителя");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля ввода для имени, телефона, категории прав и госномера,
     * а также кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField nameField = new TextField(driver.getName());
        TextField phoneField = new TextField(driver.getPhone());
        TextField licenseField = new TextField(driver.getLicenseCategory());
        TextField plateField = new TextField(driver.getVehicleLicensePlate());
        plateField.setPromptText("Госномер");

        grid.add(new Label("Имя:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Телефон:"), 0, 1);
        grid.add(phoneField, 1, 1);
        grid.add(new Label("Категория прав:"), 0, 2);
        grid.add(licenseField, 1, 2);
        grid.add(new Label("Госномер ТС:"), 0, 3);
        grid.add(plateField, 1, 3);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            driver.setName(nameField.getText());
            driver.setPhone(phoneField.getText());
            driver.setLicenseCategory(licenseField.getText());
            driver.setVehicleLicensePlate(plateField.getText().trim());
            // vehicleId не заполняем – он будет определён на сервере по номеру
            try {
                if (driver.getId() == null) {
                    apiClient.createDriver(driver);
                } else {
                    apiClient.updateDriver(driver.getId(), driver);
                }
                onSaveCallback.run();
                close();
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 4);
        grid.add(btnCancel, 1, 4);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}