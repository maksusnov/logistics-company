package com.logistics.client.util;

/**
 * Менеджер аутентификации.
 * Хранит JWT-токен и роль текущего пользователя, полученные после успешного входа.
 * Предоставляет методы для проверки статуса аутентификации и прав доступа.
 */
public class AuthManager {
    private static AuthManager instance;
    private String token;
    private String role;

    private AuthManager() {}

    /**
     * Возвращает единственный экземпляр класса.
     *
     * @return экземпляр AuthManager
     */
    public static AuthManager getInstance() {
        if (instance == null) {
            instance = new AuthManager();
        }
        return instance;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    /**
     * Проверяет, является ли текущий пользователь администратором.
     *
     * @return true, если роль пользователя ADMIN, иначе false
     */
    public boolean isAdmin() {
        return "ADMIN".equals(role);
    }

    /**
     * Проверяет, аутентифицирован ли пользователь (имеется ли сохранённый токен).
     *
     * @return true, если токен существует и не пуст, иначе false
     */
    public boolean isAuthenticated() {
        return token != null && !token.isEmpty();
    }

    /**
     * Выполняет выход из системы: очищает сохранённые токен и роль.
     */
    public void logout() {
        token = null;
        role = null;
    }
}