package com.logistics.client.dto;

/**
 * DTO для передачи данных о грузе.
 * Содержит основные поля груза: идентификатор, описание, вес, объём, тип.
 */
public class CargoDTO {
    private Long id;
    private String description;
    private Double weight;
    private Double volume;
    private CargoType cargoType;

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Double getWeight() { return weight; }
    public void setWeight(Double weight) { this.weight = weight; }
    public Double getVolume() { return volume; }
    public void setVolume(Double volume) { this.volume = volume; }
    public CargoType getCargoType() { return cargoType; }
    public void setCargoType(CargoType cargoType) { this.cargoType = cargoType; }
}
