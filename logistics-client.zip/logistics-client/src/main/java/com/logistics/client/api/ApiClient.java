package com.logistics.client.api;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.logistics.client.dto.*;
import com.logistics.client.util.AuthManager;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Клиент для взаимодействия с REST API сервера.
 * Содержит методы для аутентификации, выполнения CRUD-операций
 * над всеми сущностями, а также для получения статистики.
 * Все запросы, кроме логина, автоматически добавляют заголовок
 * Authorization с JWT-токеном текущего пользователя.
 */
public class ApiClient {
    private static final String BASE_URL = "http://localhost:8080/api/v1";
    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    // ==================== АУТЕНТИФИКАЦИЯ ====================

    /**
     * Выполняет вход в систему.
     *
     * @param request объект с логином и паролем
     * @return ответ, содержащий JWT-токен и роль пользователя
     * @throws Exception при ошибке соединения или неверных учётных данных
     */
    public LoginResponse login(LoginRequest request) throws Exception {
        String json = objectMapper.writeValueAsString(request);
        HttpRequest httpRequest = HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/auth/login"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();
        HttpResponse<String> response = httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), LoginResponse.class);
    }

    // ==================== КЛИЕНТЫ ====================

    public List<ClientDTO> getClients() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/clients"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<ClientDTO>>() {});
    }

    public ClientDTO createClient(ClientDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/clients"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), ClientDTO.class);
    }

    public ClientDTO updateClient(Long id, ClientDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/clients/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), ClientDTO.class);
    }

    public void deleteClient(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/clients/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== ГРУЗЫ ====================

    public List<CargoDTO> getCargos() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/cargos"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<CargoDTO>>() {});
    }

    public CargoDTO createCargo(CargoDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/cargos"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), CargoDTO.class);
    }

    public CargoDTO updateCargo(Long id, CargoDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/cargos/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), CargoDTO.class);
    }

    public void deleteCargo(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/cargos/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== ТРАНСПОРТ ====================

    public List<VehicleDTO> getVehicles() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/vehicles"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<VehicleDTO>>() {});
    }

    public VehicleDTO createVehicle(VehicleDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/vehicles"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), VehicleDTO.class);
    }

    public VehicleDTO updateVehicle(Long id, VehicleDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/vehicles/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), VehicleDTO.class);
    }

    public void deleteVehicle(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/vehicles/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== ВОДИТЕЛИ ====================

    public List<DriverDTO> getDrivers() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/drivers"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<DriverDTO>>() {});
    }

    public DriverDTO createDriver(DriverDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/drivers"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), DriverDTO.class);
    }

    public DriverDTO updateDriver(Long id, DriverDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/drivers/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), DriverDTO.class);
    }

    public void deleteDriver(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/drivers/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== МАРШРУТЫ ====================

    public List<RouteDTO> getRoutes() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/routes"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<RouteDTO>>() {});
    }

    public RouteDTO createRoute(RouteDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/routes"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), RouteDTO.class);
    }

    public RouteDTO updateRoute(Long id, RouteDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/routes/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), RouteDTO.class);
    }

    public void deleteRoute(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/routes/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== ЗАКАЗЫ ====================

    public List<OrderDTO> getOrders() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/orders"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<OrderDTO>>() {});
    }

    /**
     * Фильтрует заказы по заданным критериям.
     *
     * @param status    статус заказа
     * @param startDate начальная дата
     * @param endDate   конечная дата
     * @param minWeight минимальный вес груза
     * @param clientId  идентификатор клиента
     * @param driverId  идентификатор водителя
     * @return список заказов, удовлетворяющих условиям
     * @throws Exception при ошибке сети или сервера
     */
    public List<OrderDTO> filterOrders(OrderStatus status, LocalDate startDate, LocalDate endDate,
                                       Double minWeight, Long clientId, Long driverId) throws Exception {
        StringBuilder url = new StringBuilder(BASE_URL + "/orders/filter?");
        if (status != null) url.append("status=").append(status).append("&");
        if (startDate != null) url.append("startDate=").append(startDate).append("&");
        if (endDate != null) url.append("endDate=").append(endDate).append("&");
        if (minWeight != null) url.append("minWeight=").append(minWeight).append("&");
        if (clientId != null) url.append("clientId=").append(clientId).append("&");
        if (driverId != null) url.append("driverId=").append(driverId);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(url.toString()))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<OrderDTO>>() {});
    }

    public OrderDTO createOrder(OrderDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/orders"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), OrderDTO.class);
    }

    public OrderDTO updateOrder(Long id, OrderDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/orders/" + id))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), OrderDTO.class);
    }

    public void deleteOrder(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/orders/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }

    // ==================== СТАТИСТИКА ====================

    public Double getAverageWeight() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/orders/average-weight"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), Double.class);
    }

    public Map<OrderStatus, Long> getOrdersByStatus() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/orders/by-status"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<Map<OrderStatus, Long>>() {});
    }

    public long getTotalOrders() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/orders/total-count"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), Long.class);
    }

    public Map<String, Object> getMostPopularCargo() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/cargos/most-popular"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<Map<String, Object>>() {});
    }

    public Map<String, Object> getMostBusyDriver() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/drivers/most-busy"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<Map<String, Object>>() {});
    }

    public double getAverageRouteDistance() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/routes/average-distance"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), Double.class);
    }

    public double getTotalCargoWeight() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/cargos/total-weight"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), Double.class);
    }

    public Map<String, Long> getOrdersByWeekday() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/orders/by-weekday"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<Map<String, Long>>() {});
    }

    public List<Map<String, Object>> getTopCargos() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/cargos/top"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<Map<String, Object>>>() {});
    }

    public Map<String, Long> getOrdersByMonth() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/statistics/orders/by-month"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<Map<String, Long>>() {});
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ====================

    private void checkResponse(HttpResponse<String> response) {
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new RuntimeException("HTTP " + response.statusCode() + ": " + response.body());
        }
    }

    private HttpRequest.Builder addAuthHeader(HttpRequest.Builder builder) {
        String token = AuthManager.getInstance().getToken();
        if (token != null && !token.isEmpty()) {
            builder.header("Authorization", "Bearer " + token);
        }
        return builder;
    }

    // ==================== ПОЛЬЗОВАТЕЛИ ====================

    public List<UserDTO> getUsers() throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/users"))
                .GET())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), new TypeReference<List<UserDTO>>() {});
    }

    public UserDTO createUser(UserDTO dto) throws Exception {
        String json = objectMapper.writeValueAsString(dto);
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/users"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json)))
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        checkResponse(response);
        return objectMapper.readValue(response.body(), UserDTO.class);
    }

    public void deleteUser(Long id) throws Exception {
        HttpRequest request = addAuthHeader(HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/users/" + id))
                .DELETE())
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 204) {
            throw new RuntimeException("Ошибка: " + response.body());
        }
    }
}