package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.Role;
import com.logistics.client.dto.UserDTO;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования пользователя.
 * Позволяет ввести логин, пароль и выбрать роль (ADMIN/USER).
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class UserEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final UserDTO user;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param user           объект пользователя для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public UserEditDialog(UserDTO user, Runnable onSaveCallback) {
        this.user = user != null ? user : new UserDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(user == null ? "Добавление пользователя" : "Редактирование пользователя");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля для ввода логина, пароля, выпадающий список для выбора роли,
     * кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField loginField = new TextField(user.getLogin());
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Пароль");

        ComboBox<String> roleBox = new ComboBox<>();
        roleBox.getItems().addAll("ADMIN", "USER");
        if (user.getRole() != null) {
            roleBox.setValue(user.getRole());
        } else {
            roleBox.setValue("USER");
        }

        grid.add(new Label("Логин:"), 0, 0);
        grid.add(loginField, 1, 0);
        grid.add(new Label("Пароль:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(new Label("Роль:"), 0, 2);
        grid.add(roleBox, 1, 2);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            user.setLogin(loginField.getText());
            user.setPassword(passwordField.getText());
            user.setRole(roleBox.getValue());
            try {
                if (user.getId() == null) {
                    apiClient.createUser(user);
                } else {
                    // для редактирования пока не реализовано, можно добавить позже
                }
                onSaveCallback.run();
                close();
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 3);
        grid.add(btnCancel, 1, 3);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}