package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.VehicleDTO;
import com.logistics.client.dto.VehicleStatus;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.VehicleEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для отображения и управления транспортными средствами.
 * Содержит таблицу со списком ТС и панель инструментов
 * для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class VehicleView extends BorderPane {
    private final TableView<VehicleDTO> table = new TableView<>();
    private final ObservableList<VehicleDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    public VehicleView() {
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Госномер, Модель, Грузоподъёмность, Статус.
     */
    private void createTable() {
        TableColumn<VehicleDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<VehicleDTO, String> plateCol = new TableColumn<>("Госномер");
        plateCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getLicensePlate()));

        TableColumn<VehicleDTO, String> modelCol = new TableColumn<>("Модель");
        modelCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getModel()));

        TableColumn<VehicleDTO, Double> capCol = new TableColumn<>("Грузоподъёмность");
        capCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getCapacity()));

        TableColumn<VehicleDTO, String> statusCol = new TableColumn<>("Статус");
        statusCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(
                cellData.getValue().getStatus() != null ? cellData.getValue().getStatus().getDisplayName() : ""));

        table.getColumns().addAll(idCol, plateCol, modelCol, capCol, statusCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            VehicleDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите ТС для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            VehicleDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteVehicle(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить ТС: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите ТС для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getVehicles());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить ТС: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования транспортного средства.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param vehicle объект ТС для редактирования (null для нового)
     */
    private void showEditDialog(VehicleDTO vehicle) {
        VehicleEditDialog dialog = new VehicleEditDialog(vehicle, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}