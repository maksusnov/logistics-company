package com.logistics.client.dto;

/**
 * Перечисление возможных статусов заказа.
 * Каждому значению соответствует русскоязычное отображаемое имя,
 * используемое в пользовательском интерфейсе.
 */
public enum OrderStatus {
    NEW("Новый"),
    IN_TRANSIT("В пути"),
    DELIVERED("Доставлен"),
    CANCELLED("Отменён");

    private final String displayName;

    OrderStatus(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Возвращает русскоязычное название статуса для отображения в интерфейсе.
     *
     * @return отображаемое имя
     */
    public String getDisplayName() {
        return displayName;
    }
}