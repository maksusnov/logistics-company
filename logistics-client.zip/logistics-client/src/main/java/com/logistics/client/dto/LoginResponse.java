package com.logistics.client.dto;

/**
 * DTO с ответом на успешную аутентификацию.
 * Содержит JWT-токен для последующих запросов и роль пользователя.
 */
public class LoginResponse {
    private String token;
    private String role;

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}