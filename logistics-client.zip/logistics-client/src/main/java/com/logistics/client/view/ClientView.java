package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.ClientDTO;
import com.logistics.client.dto.ClientType;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.ClientEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для отображения и управления клиентами.
 * Содержит таблицу со списком клиентов и панель инструментов
 * для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class ClientView extends BorderPane {
    private final TableView<ClientDTO> table = new TableView<>();
    private final ObservableList<ClientDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    public ClientView() {
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Название, Телефон, Email, Тип.
     */
    private void createTable() {
        TableColumn<ClientDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<ClientDTO, String> nameCol = new TableColumn<>("Название");
        nameCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getName()));

        TableColumn<ClientDTO, String> phoneCol = new TableColumn<>("Телефон");
        phoneCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getPhone()));

        TableColumn<ClientDTO, String> emailCol = new TableColumn<>("Email");
        emailCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getEmail()));

        TableColumn<ClientDTO, String> typeCol = new TableColumn<>("Тип");
        typeCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(
                cellData.getValue().getType() != null ? cellData.getValue().getType().getDisplayName() : ""));

        table.getColumns().addAll(idCol, nameCol, phoneCol, emailCol, typeCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            ClientDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите клиента для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            ClientDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteClient(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить клиента: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите клиента для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getClients());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить клиентов: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования клиента.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param client объект клиента для редактирования (null для нового)
     */
    private void showEditDialog(ClientDTO client) {
        ClientEditDialog dialog = new ClientEditDialog(client, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
