package com.logistics.client.dto;

/**
 * Перечисление возможных типов груза.
 * Каждому значению соответствует русскоязычное отображаемое имя,
 * используемое в пользовательском интерфейсе.
 */
public enum CargoType {
    STANDARD("Обычный"),
    PERISHABLE("Скоропортящийся"),
    FRAGILE("Хрупкий"),
    DANGEROUS("Опасный");

    private final String displayName;

    CargoType(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Возвращает русскоязычное название типа груза для отображения в интерфейсе.
     *
     * @return отображаемое имя
     */
    public String getDisplayName() {
        return displayName;
    }
}