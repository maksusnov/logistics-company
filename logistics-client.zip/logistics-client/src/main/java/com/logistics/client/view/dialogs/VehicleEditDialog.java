package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.VehicleDTO;
import com.logistics.client.dto.VehicleStatus;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования транспортного средства (ТС).
 * Позволяет ввести госномер, модель, грузоподъёмность и выбрать статус.
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class VehicleEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final VehicleDTO vehicle;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param vehicle        объект ТС для редактирования (если null, то создаётся новое)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public VehicleEditDialog(VehicleDTO vehicle, Runnable onSaveCallback) {
        this.vehicle = vehicle != null ? vehicle : new VehicleDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(vehicle == null ? "Добавление ТС" : "Редактирование ТС");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля для ввода госномера, модели, грузоподъёмности,
     * выпадающий список для выбора статуса с русскими названиями, кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField plateField = new TextField(vehicle.getLicensePlate());
        TextField modelField = new TextField(vehicle.getModel());
        TextField capacityField = new TextField(vehicle.getCapacity() != null ? vehicle.getCapacity().toString() : "");

        // ComboBox для статуса с отображением русских названий
        ComboBox<VehicleStatus> statusBox = new ComboBox<>();
        statusBox.getItems().setAll(VehicleStatus.values());
        statusBox.setCellFactory(lv -> new ListCell<VehicleStatus>() {
            @Override
            protected void updateItem(VehicleStatus item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        statusBox.setButtonCell(new ListCell<VehicleStatus>() {
            @Override
            protected void updateItem(VehicleStatus item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        if (vehicle.getStatus() != null) {
            statusBox.setValue(vehicle.getStatus());
        } else {
            statusBox.setValue(VehicleStatus.AVAILABLE);
        }

        grid.add(new Label("Госномер:"), 0, 0);
        grid.add(plateField, 1, 0);
        grid.add(new Label("Модель:"), 0, 1);
        grid.add(modelField, 1, 1);
        grid.add(new Label("Грузоподъёмность (кг):"), 0, 2);
        grid.add(capacityField, 1, 2);
        grid.add(new Label("Статус:"), 0, 3);
        grid.add(statusBox, 1, 3);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            try {
                vehicle.setLicensePlate(plateField.getText());
                vehicle.setModel(modelField.getText());
                vehicle.setCapacity(Double.parseDouble(capacityField.getText()));
                vehicle.setStatus(statusBox.getValue());

                if (vehicle.getId() == null) {
                    apiClient.createVehicle(vehicle);
                } else {
                    apiClient.updateVehicle(vehicle.getId(), vehicle);
                }
                onSaveCallback.run();
                close();
            } catch (NumberFormatException ex) {
                showError("Грузоподъёмность должна быть числом.");
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 4);
        grid.add(btnCancel, 1, 4);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}