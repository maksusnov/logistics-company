package com.logistics.client.dto;

/**
 * DTO для передачи статистики количества заказов по статусам.
 * Содержит пару: статус заказа и соответствующее количество.
 */
public class StatusCountDTO {
    private OrderStatus status;
    private Long count;

    public StatusCountDTO() {}
    public StatusCountDTO(OrderStatus status, Long count) {
        this.status = status;
        this.count = count;
    }

    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }
    public Long getCount() { return count; }
    public void setCount(Long count) { this.count = count; }
}