package com.logistics.client.util;

import javafx.stage.Stage;
import java.util.prefs.Preferences;

/**
 * Утилитный класс для сохранения и загрузки настроек окна (размера и позиции).
 * Использует {@link Preferences} для хранения данных между сеансами работы приложения.
 */
public class PreferencesUtil {
    private static final Preferences prefs = Preferences.userNodeForPackage(PreferencesUtil.class);

    /**
     * Сохраняет текущее положение и размеры окна в хранилище настроек.
     *
     * @param stage объект окна, чьи координаты и размеры необходимо сохранить
     */
    public static void saveWindowPosition(Stage stage) {
        prefs.putDouble("window.x", stage.getX());
        prefs.putDouble("window.y", stage.getY());
        prefs.putDouble("window.width", stage.getWidth());
        prefs.putDouble("window.height", stage.getHeight());
    }

    /**
     * Загружает ранее сохранённые положение и размеры окна из хранилища настроек
     * и применяет их к указанному окну. Если сохранённых данных нет,
     * используются значения по умолчанию (100, 100, 1200, 600).
     *
     * @param stage объект окна, к которому будут применены загруженные параметры
     */
    public static void loadWindowPosition(Stage stage) {
        double x = prefs.getDouble("window.x", 100);
        double y = prefs.getDouble("window.y", 100);
        double width = prefs.getDouble("window.width", 1200);
        double height = prefs.getDouble("window.height", 600);
        stage.setX(x);
        stage.setY(y);
        stage.setWidth(width);
        stage.setHeight(height);
    }
}