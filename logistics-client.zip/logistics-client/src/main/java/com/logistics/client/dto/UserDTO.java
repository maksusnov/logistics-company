package com.logistics.client.dto;

/**
 * DTO для передачи данных о пользователе.
 * Содержит идентификатор, логин, роль и пароль.
 * Поле password используется только при создании нового пользователя или смене пароля;
 * при получении списка пользователей пароль не передаётся.
 */
public class UserDTO {
    private Long id;
    private String login;
    private String role;
    private String password;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}