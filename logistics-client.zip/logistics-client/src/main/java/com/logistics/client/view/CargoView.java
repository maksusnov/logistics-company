package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.CargoDTO;
import com.logistics.client.dto.CargoType;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.CargoEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для отображения и управления грузами.
 * Содержит таблицу со списком грузов и панель инструментов
 * для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class CargoView extends BorderPane {
    private final TableView<CargoDTO> table = new TableView<>();
    private final ObservableList<CargoDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    public CargoView() {
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Описание, Вес, Объём, Тип груза.
     */
    private void createTable() {
        TableColumn<CargoDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<CargoDTO, String> descCol = new TableColumn<>("Описание");
        descCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getDescription()));

        TableColumn<CargoDTO, Double> weightCol = new TableColumn<>("Вес (кг)");
        weightCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getWeight()));

        TableColumn<CargoDTO, Double> volumeCol = new TableColumn<>("Объём (м³)");
        volumeCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getVolume()));

        TableColumn<CargoDTO, String> typeCol = new TableColumn<>("Тип груза");
        typeCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(
                cellData.getValue().getCargoType() != null ? cellData.getValue().getCargoType().getDisplayName() : ""));

        table.getColumns().addAll(idCol, descCol, weightCol, volumeCol, typeCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            CargoDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите груз для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            CargoDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteCargo(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить груз: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите груз для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getCargos());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить грузы: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования груза.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param cargo объект груза для редактирования (null для нового)
     */
    private void showEditDialog(CargoDTO cargo) {
        CargoEditDialog dialog = new CargoEditDialog(cargo, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}