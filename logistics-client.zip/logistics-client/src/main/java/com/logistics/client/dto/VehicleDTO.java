package com.logistics.client.dto;

/**
 * DTO для передачи данных о транспортном средстве.
 * Содержит основную информацию: идентификатор, госномер, модель, грузоподъёмность, статус.
 */
public class VehicleDTO {
    private Long id;
    private String licensePlate;
    private String model;
    private Double capacity;
    private VehicleStatus status;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getLicensePlate() { return licensePlate; }
    public void setLicensePlate(String licensePlate) { this.licensePlate = licensePlate; }
    public String getModel() { return model; }
    public void setModel(String model) { this.model = model; }
    public Double getCapacity() { return capacity; }
    public void setCapacity(Double capacity) { this.capacity = capacity; }
    public VehicleStatus getStatus() { return status; }
    public void setStatus(VehicleStatus status) { this.status = status; }
}