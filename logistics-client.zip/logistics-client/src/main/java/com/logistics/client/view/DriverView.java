package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.DriverDTO;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.DriverEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для отображения и управления водителями.
 * Содержит таблицу со списком водителей и панель инструментов
 * для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class DriverView extends BorderPane {
    private final TableView<DriverDTO> table = new TableView<>();
    private final ObservableList<DriverDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    public DriverView() {
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Имя, Телефон, Категория прав, Транспорт.
     * В колонке "Транспорт" отображается госномер закреплённого ТС.
     */
    private void createTable() {
        TableColumn<DriverDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<DriverDTO, String> nameCol = new TableColumn<>("Имя");
        nameCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getName()));

        TableColumn<DriverDTO, String> phoneCol = new TableColumn<>("Телефон");
        phoneCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getPhone()));

        TableColumn<DriverDTO, String> licenseCol = new TableColumn<>("Категория");
        licenseCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getLicenseCategory()));

        TableColumn<DriverDTO, String> vehicleCol = new TableColumn<>("Транспорт");
        vehicleCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getVehicleLicensePlate()));

        table.getColumns().addAll(idCol, nameCol, phoneCol, licenseCol, vehicleCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            DriverDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите водителя для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            DriverDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteDriver(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить водителя: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите водителя для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getDrivers());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить водителей: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования водителя.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param driver объект водителя для редактирования (null для нового)
     */
    private void showEditDialog(DriverDTO driver) {
        DriverEditDialog dialog = new DriverEditDialog(driver, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}