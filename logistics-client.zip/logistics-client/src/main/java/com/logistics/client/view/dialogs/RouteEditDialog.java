package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.RouteDTO;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования маршрута.
 * Позволяет ввести пункт отправления, пункт назначения и расстояние.
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class RouteEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final RouteDTO route;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param route          объект маршрута для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public RouteEditDialog(RouteDTO route, Runnable onSaveCallback) {
        this.route = route != null ? route : new RouteDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(route == null ? "Добавление маршрута" : "Редактирование маршрута");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля для ввода пунктов отправления, назначения и расстояния,
     * а также кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField departureField = new TextField(route.getDeparture());
        TextField destinationField = new TextField(route.getDestination());
        TextField distanceField = new TextField(
                route.getDistance() != null ? route.getDistance().toString() : "");

        grid.add(new Label("Отправление:"), 0, 0);
        grid.add(departureField, 1, 0);
        grid.add(new Label("Назначение:"), 0, 1);
        grid.add(destinationField, 1, 1);
        grid.add(new Label("Расстояние (км):"), 0, 2);
        grid.add(distanceField, 1, 2);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            try {
                route.setDeparture(departureField.getText().trim());
                route.setDestination(destinationField.getText().trim());
                route.setDistance(Double.parseDouble(distanceField.getText().trim()));

                if (route.getId() == null) {
                    apiClient.createRoute(route);
                } else {
                    apiClient.updateRoute(route.getId(), route);
                }
                onSaveCallback.run();
                close();
            } catch (NumberFormatException ex) {
                showError("Расстояние должно быть числом.");
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 3);
        grid.add(btnCancel, 1, 3);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
