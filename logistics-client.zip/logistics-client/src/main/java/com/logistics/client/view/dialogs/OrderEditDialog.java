package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.*;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.time.LocalDate;
import java.util.List;

/**
 * Модальное окно для добавления или редактирования заказа.
 * Позволяет выбрать дату, статус, клиента, груз, маршрут, водителя и транспортное средство
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class OrderEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final OrderDTO order;
    private final Runnable onSaveCallback;

    private ComboBox<ClientDTO> clientBox;
    private ComboBox<CargoDTO> cargoBox;
    private ComboBox<RouteDTO> routeBox;
    private ComboBox<DriverDTO> driverBox;
    private ComboBox<VehicleDTO> vehicleBox;
    private DatePicker datePicker;
    private ComboBox<OrderStatus> statusBox;

    /**
     * Конструктор диалога.
     *
     * @param order          объект заказа для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public OrderEditDialog(OrderDTO order, Runnable onSaveCallback) {
        this.order = order != null ? order : new OrderDTO();
        this.order.setOrderDate(LocalDate.now()); // по умолчанию сегодня
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(order == null ? "Добавление заказа" : "Редактирование заказа");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля для даты, статуса и выпадающие списки для связанных сущностей.
     * Загружает данные для списков с сервера.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        // Дата
        datePicker = new DatePicker(order.getOrderDate());
        datePicker.setEditable(false);

        // Статус с русскими названиями
        statusBox = new ComboBox<>();
        statusBox.getItems().setAll(OrderStatus.values());
        statusBox.setCellFactory(lv -> new ListCell<OrderStatus>() {
            @Override
            protected void updateItem(OrderStatus item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        statusBox.setButtonCell(new ListCell<OrderStatus>() {
            @Override
            protected void updateItem(OrderStatus item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        statusBox.setValue(order.getStatus() != null ? order.getStatus() : OrderStatus.NEW);

        // Загружаем справочники
        try {
            List<ClientDTO> clients = apiClient.getClients();
            clientBox = new ComboBox<>(FXCollections.observableArrayList(clients));
            clientBox.setCellFactory(lv -> new ListCell<ClientDTO>() {
                @Override
                protected void updateItem(ClientDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getName());
                }
            });
            clientBox.setButtonCell(new ListCell<ClientDTO>() {
                @Override
                protected void updateItem(ClientDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getName());
                }
            });
            if (order.getClientId() != null) {
                clients.stream()
                        .filter(c -> c.getId().equals(order.getClientId()))
                        .findFirst()
                        .ifPresent(clientBox::setValue);
            }

            List<CargoDTO> cargos = apiClient.getCargos();
            cargoBox = new ComboBox<>(FXCollections.observableArrayList(cargos));
            cargoBox.setCellFactory(lv -> new ListCell<CargoDTO>() {
                @Override
                protected void updateItem(CargoDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getDescription());
                }
            });
            cargoBox.setButtonCell(new ListCell<CargoDTO>() {
                @Override
                protected void updateItem(CargoDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getDescription());
                }
            });
            if (order.getCargoId() != null) {
                cargos.stream()
                        .filter(c -> c.getId().equals(order.getCargoId()))
                        .findFirst()
                        .ifPresent(cargoBox::setValue);
            }

            List<RouteDTO> routes = apiClient.getRoutes();
            routeBox = new ComboBox<>(FXCollections.observableArrayList(routes));
            routeBox.setCellFactory(lv -> new ListCell<RouteDTO>() {
                @Override
                protected void updateItem(RouteDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getDeparture() + " → " + item.getDestination());
                }
            });
            routeBox.setButtonCell(new ListCell<RouteDTO>() {
                @Override
                protected void updateItem(RouteDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getDeparture() + " → " + item.getDestination());
                }
            });
            if (order.getRouteId() != null) {
                routes.stream()
                        .filter(r -> r.getId().equals(order.getRouteId()))
                        .findFirst()
                        .ifPresent(routeBox::setValue);
            }

            List<DriverDTO> drivers = apiClient.getDrivers();
            driverBox = new ComboBox<>(FXCollections.observableArrayList(drivers));
            driverBox.setCellFactory(lv -> new ListCell<DriverDTO>() {
                @Override
                protected void updateItem(DriverDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getName());
                }
            });
            driverBox.setButtonCell(new ListCell<DriverDTO>() {
                @Override
                protected void updateItem(DriverDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getName());
                }
            });
            if (order.getDriverId() != null) {
                drivers.stream()
                        .filter(d -> d.getId().equals(order.getDriverId()))
                        .findFirst()
                        .ifPresent(driverBox::setValue);
            }

            List<VehicleDTO> vehicles = apiClient.getVehicles();
            vehicleBox = new ComboBox<>(FXCollections.observableArrayList(vehicles));
            vehicleBox.setCellFactory(lv -> new ListCell<VehicleDTO>() {
                @Override
                protected void updateItem(VehicleDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getLicensePlate() + " (" + item.getModel() + ")");
                }
            });
            vehicleBox.setButtonCell(new ListCell<VehicleDTO>() {
                @Override
                protected void updateItem(VehicleDTO item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? null : item.getLicensePlate() + " (" + item.getModel() + ")");
                }
            });
            if (order.getVehicleId() != null) {
                vehicles.stream()
                        .filter(v -> v.getId().equals(order.getVehicleId()))
                        .findFirst()
                        .ifPresent(vehicleBox::setValue);
            }

        } catch (Exception e) {
            showError("Не удалось загрузить справочники: " + e.getMessage());
            close();
        }

        // Размещение на форме
        int row = 0;
        grid.add(new Label("Дата заказа:"), 0, row);
        grid.add(datePicker, 1, row++);
        grid.add(new Label("Статус:"), 0, row);
        grid.add(statusBox, 1, row++);
        grid.add(new Label("Клиент:"), 0, row);
        grid.add(clientBox, 1, row++);
        grid.add(new Label("Груз:"), 0, row);
        grid.add(cargoBox, 1, row++);
        grid.add(new Label("Маршрут:"), 0, row);
        grid.add(routeBox, 1, row++);
        grid.add(new Label("Водитель:"), 0, row);
        grid.add(driverBox, 1, row++);
        grid.add(new Label("Транспорт:"), 0, row);
        grid.add(vehicleBox, 1, row++);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            try {
                order.setOrderDate(datePicker.getValue());
                order.setStatus(statusBox.getValue());
                if (clientBox.getValue() != null) order.setClientId(clientBox.getValue().getId());
                if (cargoBox.getValue() != null) order.setCargoId(cargoBox.getValue().getId());
                if (routeBox.getValue() != null) order.setRouteId(routeBox.getValue().getId());
                if (driverBox.getValue() != null) order.setDriverId(driverBox.getValue().getId());
                if (vehicleBox.getValue() != null) order.setVehicleId(vehicleBox.getValue().getId());

                if (order.getId() == null) {
                    apiClient.createOrder(order);
                } else {
                    apiClient.updateOrder(order.getId(), order);
                }
                onSaveCallback.run();
                close();
            } catch (Exception ex) {
                showError("Не удалось сохранить заказ: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, row);
        grid.add(btnCancel, 1, row++);

        Scene scene = new Scene(grid, 400, 500);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}