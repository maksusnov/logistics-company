package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.CargoDTO;
import com.logistics.client.dto.CargoType;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования груза.
 * Позволяет ввести описание, вес, объём и выбрать тип груза.
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class CargoEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final CargoDTO cargo;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param cargo          объект груза для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public CargoEditDialog(CargoDTO cargo, Runnable onSaveCallback) {
        this.cargo = cargo != null ? cargo : new CargoDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(cargo == null ? "Добавление груза" : "Редактирование груза");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля ввода, комбобокс для типа груза, кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField descField = new TextField(cargo.getDescription());
        TextField weightField = new TextField(cargo.getWeight() != null ? cargo.getWeight().toString() : "");
        TextField volumeField = new TextField(cargo.getVolume() != null ? cargo.getVolume().toString() : "");

        // ComboBox для типа груза с отображением русских названий
        ComboBox<CargoType> typeBox = new ComboBox<>();
        typeBox.getItems().setAll(CargoType.values());
        typeBox.setCellFactory(lv -> new ListCell<CargoType>() {
            @Override
            protected void updateItem(CargoType item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        typeBox.setButtonCell(new ListCell<CargoType>() {
            @Override
            protected void updateItem(CargoType item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        if (cargo.getCargoType() != null) {
            typeBox.setValue(cargo.getCargoType());
        } else {
            typeBox.setValue(CargoType.STANDARD);
        }

        grid.add(new Label("Описание:"), 0, 0);
        grid.add(descField, 1, 0);
        grid.add(new Label("Вес (кг):"), 0, 1);
        grid.add(weightField, 1, 1);
        grid.add(new Label("Объём (м³):"), 0, 2);
        grid.add(volumeField, 1, 2);
        grid.add(new Label("Тип груза:"), 0, 3);
        grid.add(typeBox, 1, 3);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            try {
                cargo.setDescription(descField.getText());
                cargo.setWeight(Double.parseDouble(weightField.getText()));
                cargo.setVolume(Double.parseDouble(volumeField.getText()));
                cargo.setCargoType(typeBox.getValue());

                if (cargo.getId() == null) {
                    apiClient.createCargo(cargo);
                } else {
                    apiClient.updateCargo(cargo.getId(), cargo);
                }
                onSaveCallback.run();
                close();
            } catch (NumberFormatException ex) {
                showError("Вес и объём должны быть числами.");
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 4);
        grid.add(btnCancel, 1, 4);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}