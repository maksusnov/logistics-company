package com.logistics.client.dto;

/**
 * Перечисление возможных статусов транспортного средства.
 * Каждому значению соответствует русскоязычное отображаемое имя,
 * используемое в пользовательском интерфейсе.
 */
public enum VehicleStatus {
    AVAILABLE("Доступен"),
    ON_ROUTE("В рейсе"),
    MAINTENANCE("На обслуживании");

    private final String displayName;

    VehicleStatus(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Возвращает русскоязычное название статуса для отображения в интерфейсе.
     *
     * @return отображаемое имя
     */
    public String getDisplayName() {
        return displayName;
    }
}
