package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.Role;
import com.logistics.client.dto.UserDTO;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.UserEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для управления пользователями системы.
 * Доступна только администраторам. Содержит таблицу с логинами и ролями,
 * а также панель инструментов для добавления, удаления и обновления записей.
 */
public class UserView extends BorderPane {
    private final TableView<UserDTO> table = new TableView<>();
    private final ObservableList<UserDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    /**
     * Конструктор вкладки. Если текущий пользователь не является администратором,
     * вместо таблицы отображается сообщение о запрете доступа.
     */
    public UserView() {
        if (!AuthManager.getInstance().isAdmin()) {
            setCenter(new Label("Доступ запрещён"));
            return;
        }
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Логин, Роль.
     */
    private void createTable() {
        TableColumn<UserDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<UserDTO, String> loginCol = new TableColumn<>("Логин");
        loginCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getLogin()));

        TableColumn<UserDTO, String> roleCol = new TableColumn<>("Роль");
        roleCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getRole()));

        table.getColumns().addAll(idCol, loginCol, roleCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Удалить, Обновить.
     */
    private void createToolbar() {
        Button btnAdd = new Button("Добавить");
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnDelete = new Button("Удалить");
        btnDelete.setOnAction(e -> {
            UserDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteUser(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить пользователя: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите пользователя для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает список пользователей с сервера и обновляет таблицу.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getUsers());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить пользователей: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования пользователя.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param user объект пользователя для редактирования (null для нового)
     */
    private void showEditDialog(UserDTO user) {
        UserEditDialog dialog = new UserEditDialog(user, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}