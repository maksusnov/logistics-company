package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.RouteDTO;
import com.logistics.client.util.AuthManager;
import com.logistics.client.view.dialogs.RouteEditDialog;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

/**
 * Вкладка для отображения и управления маршрутами.
 * Содержит таблицу со списком маршрутов и панель инструментов
 * для добавления, редактирования, удаления и обновления записей.
 * Доступ к операциям изменения ограничен ролью ADMIN.
 */
public class RouteView extends BorderPane {
    private final TableView<RouteDTO> table = new TableView<>();
    private final ObservableList<RouteDTO> data = FXCollections.observableArrayList();
    private final ApiClient apiClient = new ApiClient();

    public RouteView() {
        createTable();
        createToolbar();
        loadData();
    }

    /**
     * Создаёт таблицу с колонками: ID, Отправление, Назначение, Расстояние.
     */
    private void createTable() {
        TableColumn<RouteDTO, Long> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getId()));

        TableColumn<RouteDTO, String> departureCol = new TableColumn<>("Отправление");
        departureCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getDeparture()));

        TableColumn<RouteDTO, String> destinationCol = new TableColumn<>("Назначение");
        destinationCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getDestination()));

        TableColumn<RouteDTO, Double> distanceCol = new TableColumn<>("Расстояние (км)");
        distanceCol.setCellValueFactory(cellData -> new ReadOnlyObjectWrapper<>(cellData.getValue().getDistance()));

        table.getColumns().addAll(idCol, departureCol, destinationCol, distanceCol);
        table.setItems(data);
        setCenter(table);
    }

    /**
     * Создаёт панель инструментов с кнопками Добавить, Изменить, Удалить, Обновить.
     * Кнопки изменения неактивны для пользователей с ролью USER.
     */
    private void createToolbar() {
        boolean isAdmin = AuthManager.getInstance().isAdmin();

        Button btnAdd = new Button("Добавить");
        btnAdd.setDisable(!isAdmin);
        btnAdd.setOnAction(e -> showEditDialog(null));

        Button btnEdit = new Button("Изменить");
        btnEdit.setDisable(!isAdmin);
        btnEdit.setOnAction(e -> {
            RouteDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) showEditDialog(selected);
            else showAlert("Ошибка", "Выберите маршрут для редактирования.");
        });

        Button btnDelete = new Button("Удалить");
        btnDelete.setDisable(!isAdmin);
        btnDelete.setOnAction(e -> {
            RouteDTO selected = table.getSelectionModel().getSelectedItem();
            if (selected != null) {
                try {
                    apiClient.deleteRoute(selected.getId());
                    data.remove(selected);
                } catch (Exception ex) {
                    showAlert("Ошибка", "Не удалось удалить маршрут: " + ex.getMessage());
                }
            } else {
                showAlert("Ошибка", "Выберите маршрут для удаления.");
            }
        });

        Button btnRefresh = new Button("Обновить");
        btnRefresh.setOnAction(e -> loadData());

        ToolBar toolBar = new ToolBar(btnAdd, btnEdit, btnDelete, btnRefresh);
        setTop(toolBar);
    }

    /**
     * Загружает данные с сервера и обновляет содержимое таблицы.
     * В случае ошибки показывает диалог с сообщением.
     */
    private void loadData() {
        try {
            data.setAll(apiClient.getRoutes());
        } catch (Exception e) {
            showAlert("Ошибка", "Не удалось загрузить маршруты: " + e.getMessage());
        }
    }

    /**
     * Открывает диалог для добавления/редактирования маршрута.
     * После закрытия диалога таблица автоматически обновляется.
     *
     * @param route объект маршрута для редактирования (null для нового)
     */
    private void showEditDialog(RouteDTO route) {
        RouteEditDialog dialog = new RouteEditDialog(route, this::loadData);
        dialog.showAndWait();
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param title   заголовок окна
     * @param message текст сообщения
     */
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}