package com.logistics.client.dto;

/**
 * DTO для передачи данных о клиенте.
 * Содержит основные поля: идентификатор, наименование, телефон, email, тип клиента.
 */
public class ClientDTO {
    private Long id;
    private String name;
    private String phone;
    private String email;
    private ClientType type;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public ClientType getType() { return type; }
    public void setType(ClientType type) { this.type = type; }
}