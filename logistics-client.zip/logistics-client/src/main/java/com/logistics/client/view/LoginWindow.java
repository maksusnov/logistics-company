package com.logistics.client.view;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.LoginRequest;
import com.logistics.client.dto.LoginResponse;
import com.logistics.client.util.AuthManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * Окно входа в систему.
 * Запрашивает у пользователя логин и пароль, отправляет запрос на сервер,
 * при успехе сохраняет токен и роль через {@link AuthManager} и запускает
 * переданный callback для открытия главного окна.
 */
public class LoginWindow extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final Runnable onSuccess;

    /**
     * Конструктор окна входа.
     *
     * @param onSuccess callback, который будет вызван после успешной аутентификации
     */
    public LoginWindow(Runnable onSuccess) {
        this.onSuccess = onSuccess;
        setTitle("Вход в систему");
        setResizable(false);
        initUI();
    }

    /**
     * Инициализирует пользовательский интерфейс окна входа.
     * Создаёт поля для ввода логина и пароля, кнопки "Войти" и "Отмена",
     * а также метку для отображения сообщений об ошибках.
     */
    private void initUI() {
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(25));

        Label loginLabel = new Label("Логин:");
        grid.add(loginLabel, 0, 0);
        TextField loginField = new TextField();
        grid.add(loginField, 1, 0);

        Label passwordLabel = new Label("Пароль:");
        grid.add(passwordLabel, 0, 1);
        PasswordField passwordField = new PasswordField();
        grid.add(passwordField, 1, 1);

        Button loginBtn = new Button("Войти");
        Button cancelBtn = new Button("Отмена");

        HBox buttonBox = new HBox(10, loginBtn, cancelBtn);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        grid.add(buttonBox, 1, 2);

        Label messageLabel = new Label();
        messageLabel.setStyle("-fx-text-fill: red;");
        grid.add(messageLabel, 1, 3);

        loginBtn.setOnAction(e -> {
            String login = loginField.getText();
            String password = passwordField.getText();
            if (login.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Введите логин и пароль");
                return;
            }
            try {
                LoginResponse response = apiClient.login(new LoginRequest(login, password));
                AuthManager.getInstance().setToken(response.getToken());
                AuthManager.getInstance().setRole(response.getRole());
                messageLabel.setText("");
                close();
                onSuccess.run();
            } catch (Exception ex) {
                messageLabel.setText("Ошибка: " + ex.getMessage());
            }
        });

        cancelBtn.setOnAction(e -> System.exit(0));

        Scene scene = new Scene(grid, 300, 200);
        setScene(scene);
    }
}