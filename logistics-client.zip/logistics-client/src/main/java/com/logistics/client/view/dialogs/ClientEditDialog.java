package com.logistics.client.view.dialogs;

import com.logistics.client.api.ApiClient;
import com.logistics.client.dto.ClientDTO;
import com.logistics.client.dto.ClientType;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Модальное окно для добавления или редактирования клиента.
 * Позволяет ввести название, телефон, email и выбрать тип клиента.
 * После сохранения вызывает callback для обновления данных в родительском окне.
 */
public class ClientEditDialog extends Stage {
    private final ApiClient apiClient = new ApiClient();
    private final ClientDTO client;
    private final Runnable onSaveCallback;

    /**
     * Конструктор диалога.
     *
     * @param client         объект клиента для редактирования (если null, то создаётся новый)
     * @param onSaveCallback функция, которая будет вызвана после успешного сохранения
     */
    public ClientEditDialog(ClientDTO client, Runnable onSaveCallback) {
        this.client = client != null ? client : new ClientDTO();
        this.onSaveCallback = onSaveCallback;
        initModality(Modality.APPLICATION_MODAL);
        setTitle(client == null ? "Добавление клиента" : "Редактирование клиента");
        createUI();
    }

    /**
     * Создаёт интерфейс диалога: поля ввода, комбобокс для типа клиента, кнопки Сохранить/Отмена.
     */
    private void createUI() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(5);
        grid.setVgap(5);

        TextField nameField = new TextField(client.getName());
        TextField phoneField = new TextField(client.getPhone());
        TextField emailField = new TextField(client.getEmail());

        // ComboBox для типа клиента с русскими названиями
        ComboBox<ClientType> typeBox = new ComboBox<>();
        typeBox.getItems().setAll(ClientType.values());
        // Настройка отображения ячеек
        typeBox.setCellFactory(lv -> new ListCell<ClientType>() {
            @Override
            protected void updateItem(ClientType item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        // Настройка отображения выбранного значения
        typeBox.setButtonCell(new ListCell<ClientType>() {
            @Override
            protected void updateItem(ClientType item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.getDisplayName());
            }
        });
        // Устанавливаем текущее значение
        if (client.getType() != null) {
            typeBox.setValue(client.getType());
        } else {
            typeBox.setValue(ClientType.INDIVIDUAL);
        }

        grid.add(new Label("Название:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Телефон:"), 0, 1);
        grid.add(phoneField, 1, 1);
        grid.add(new Label("Email:"), 0, 2);
        grid.add(emailField, 1, 2);
        grid.add(new Label("Тип:"), 0, 3);
        grid.add(typeBox, 1, 3);

        Button btnSave = new Button("Сохранить");
        btnSave.setOnAction(e -> {
            client.setName(nameField.getText());
            client.setPhone(phoneField.getText());
            client.setEmail(emailField.getText());
            client.setType(typeBox.getValue());
            try {
                if (client.getId() == null) {
                    apiClient.createClient(client);
                } else {
                    apiClient.updateClient(client.getId(), client);
                }
                onSaveCallback.run();
                close();
            } catch (Exception ex) {
                showError("Не удалось сохранить: " + ex.getMessage());
            }
        });

        Button btnCancel = new Button("Отмена");
        btnCancel.setOnAction(e -> close());

        grid.add(btnSave, 0, 4);
        grid.add(btnCancel, 1, 4);

        Scene scene = new Scene(grid);
        setScene(scene);
    }

    /**
     * Отображает диалог с сообщением об ошибке.
     *
     * @param message текст ошибки
     */
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}